#import "GPUImage3x3TextureSamplingFilter.h"

@interface GPUImageLocalBinaryPatternFilter : GPUImage3x3TextureSamplingFilter

@end
