#import "GPUImageGaussianBlurFilter.h"

@interface GPUImageBilateralFilter : GPUImageGaussianBlurFilter

@end
